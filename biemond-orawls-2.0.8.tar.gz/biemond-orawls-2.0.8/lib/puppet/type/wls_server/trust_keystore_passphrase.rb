newparam(:trust_keystore_passphrase) do
  include EasyType

  desc 'The trust keystore passphrase'

end
