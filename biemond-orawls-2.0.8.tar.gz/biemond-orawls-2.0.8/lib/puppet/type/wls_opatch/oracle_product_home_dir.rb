newparam(:oracle_product_home_dir) do
  desc <<-EOT
    The oracle product home folder.
  EOT
end
