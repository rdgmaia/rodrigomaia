newparam(:orainst_dir) do
  desc <<-EOT
    The orainst folder.
  EOT
end
