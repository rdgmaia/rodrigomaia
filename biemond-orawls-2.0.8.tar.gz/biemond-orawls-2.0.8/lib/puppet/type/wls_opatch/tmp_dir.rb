newparam(:tmp_dir) do
  desc <<-EOT
    The tmp extract directory of the patch.
  EOT

  defaultto '/tmp'
end
