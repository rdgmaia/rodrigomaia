newparam(:jdk_home_dir) do
  desc <<-EOT
    The JDK home folder.
  EOT
end
