newparam(:os_user) do
  desc <<-EOT
    The weblogic operating system user.
  EOT
end
