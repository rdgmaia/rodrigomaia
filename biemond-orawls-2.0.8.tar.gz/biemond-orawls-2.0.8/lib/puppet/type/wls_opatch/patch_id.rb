newparam(:patch_id) do
  desc <<-EOT
    The patchId of the OPatch.
  EOT
end
