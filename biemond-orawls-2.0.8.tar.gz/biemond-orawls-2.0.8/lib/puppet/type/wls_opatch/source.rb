newparam(:source) do
  desc <<-EOT
    The source of the patch. Can be either an extracted folder or the raw zip file.
  EOT
end
