newparam(:datasource_name) do
  include EasyType

  isnamevar

  desc 'The datasource name'

end
