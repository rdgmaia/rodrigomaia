newparam(:link_name) do
  include EasyType

  isnamevar

  desc 'The link name'

end
