newparam(:errordestinationtype) do
  include EasyType

  desc 'error destination jms type of the topic'

end
