newparam(:migratable_target_name) do
  include EasyType

  isnamevar

  desc 'The name of this migratable target'
end
