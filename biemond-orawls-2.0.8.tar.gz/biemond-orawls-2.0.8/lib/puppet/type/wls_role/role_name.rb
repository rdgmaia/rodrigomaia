newparam(:role_name) do
  include EasyType

  isnamevar

  desc 'The role name'

end
