newparam(:user_name) do
  include EasyType

  isnamevar

  desc 'The user name'

end
