newparam(:planpath) do
  include EasyType

  desc 'The path of the deploymentplan'

  isnamevar

end
