newparam(:custom_identity_privatekey_passphrase) do
  include EasyType

  desc 'The custom identity privatekey passphrase'

end
