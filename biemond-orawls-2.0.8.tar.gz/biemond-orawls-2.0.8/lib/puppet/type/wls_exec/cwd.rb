
newparam(:cwd) do

  desc <<-EOD
  The default directory from where the scripts will be run. If not specfied, this will be /tmp. 
  EOD

end
