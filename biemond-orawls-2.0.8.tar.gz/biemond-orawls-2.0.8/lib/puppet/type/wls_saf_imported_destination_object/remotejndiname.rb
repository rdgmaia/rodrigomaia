newproperty(:remotejndiname) do
  include EasyType

  desc 'The Remote JNDI of the SAF imported destination object'

  to_translate_to_resource do | raw_resource|
    raw_resource['remotejndiname']
  end

end
