newparam(:authentication_provider_name) do
  include EasyType

  isnamevar

  desc 'The authentication provider name'

end
