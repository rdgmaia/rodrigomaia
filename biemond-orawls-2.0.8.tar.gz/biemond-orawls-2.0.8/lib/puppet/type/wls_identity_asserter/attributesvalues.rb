newparam(:attributesvalues) do
  include EasyType

  desc 'The extra authentication provider property values'

end
