newparam(:attributes) do
  include EasyType

  desc 'The extra authentication provider properties'

end
